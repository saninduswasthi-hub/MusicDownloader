plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.musicdownloader"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.musicdownloader"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("org.jaudiotagger:jaudiotagger:3.0.1")
}
