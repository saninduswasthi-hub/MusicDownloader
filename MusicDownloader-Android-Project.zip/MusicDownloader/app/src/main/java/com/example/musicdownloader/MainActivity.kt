package com.example.musicdownloader

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var link: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private var trackTitle = ""
    private var artist = ""
    private var album = ""
    private var artworkUrl = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 16, 18)
        window.navigationBarColor = Color.BLACK
        handleIncoming(intent)
        buildUi()
        if (link.text.isNotBlank()) lookupSharedLink()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
        if (::link.isInitialized) {
            link.setText(intent.getStringExtra(Intent.EXTRA_TEXT) ?: "")
            lookupSharedLink()
        }
    }

    private fun handleIncoming(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val shared = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            if (::link.isInitialized) link.setText(shared) else pending = shared
        }
    }
    private var pending = ""

    private fun buildUi() {
        val bg = Color.rgb(18, 18, 21)
        val white = Color.WHITE
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(bg)
        }
        fun label(s: String, size: Float, color: Int = white) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10)
        }
        root.addView(label("MUSIC DOWNLOADER", 23f))
        root.addView(label("Share a YouTube Music link here, or paste an authorised direct MP3 URL.", 14f, 0xFFBDBDC4.toInt()))
        link = EditText(this).apply {
            setTextColor(white); setHintTextColor(0xFF888890.toInt())
            hint = "Paste or share a music link"
            setSingleLine(false); minLines = 2
            setBackgroundColor(0xFF29292F.toInt())
            setPadding(14, 12, 14, 12)
            setText(pending)
        }
        root.addView(link, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        val lookup = Button(this).apply { text = "Identify track"; setOnClickListener { lookupSharedLink() } }
        root.addView(lookup)
        details = label("Track details will appear here.", 14f, 0xFFBDBDC4.toInt())
        root.addView(details)
        val dl = Button(this).apply {
            text = "Download authorised MP3"
            setOnClickListener { downloadDirectMp3() }
        }
        root.addView(dl)
        status = label("Output: MP3 • artwork + ID3 details • Music/Downloaded", 13f, 0xFF8BC7A2.toInt())
        root.addView(status)
        root.addView(label("Important: YouTube Music links are used for identification only. This app does not extract audio from YouTube. Use a direct audio URL only when you have permission to download it.", 12f, 0xFFFFC36B.toInt()))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun lookupSharedLink() {
        val raw = link.text.toString().trim()
        if (raw.isBlank()) { status.text = "Share or paste a link first."; return }
        status.text = "Looking up track information…"
        worker.execute {
            try {
                val watch = normalizeYoutubeUrl(raw)
                val api = URL("https://www.youtube.com/oembed?url=" +
                    URLEncoder.encode(watch, "UTF-8") + "&format=json")
                val conn = api.openConnection() as HttpURLConnection
                conn.connectTimeout = 12000; conn.readTimeout = 12000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                trackTitle = Regex("\"title\"\\s*:\\s*\"(.*?)\"").find(body)?.groupValues?.get(1)
                    ?.replace("\\\\\"", "\"") ?: "Unknown title"
                artist = Regex("\"author_name\"\\s*:\\s*\"(.*?)\"").find(body)?.groupValues?.get(1) ?: ""
                artworkUrl = Regex("\"thumbnail_url\"\\s*:\\s*\"(.*?)\"").find(body)?.groupValues?.get(1) ?: ""
                album = "YouTube Music"
                runOnUiThread {
                    details.text = "Title: $trackTitle\\nArtist/channel: $artist\\nArtwork: ${if (artworkUrl.isNotBlank()) "available" else "not available"}"
                    status.text = "Track identified. Provide an authorised direct MP3 URL to download."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not identify this link. Check the URL and internet connection." }
            }
        }
    }

    private fun normalizeYoutubeUrl(raw: String): String {
        val uri = Uri.parse(raw)
        val id = uri.getQueryParameter("v") ?: uri.lastPathSegment
        return if (raw.contains("youtube.com") || raw.contains("youtu.be")) {
            if (id.isNullOrBlank()) raw else "https://www.youtube.com/watch?v=$id"
        } else raw
    }

    private fun downloadDirectMp3() {
        val raw = link.text.toString().trim()
        if (!raw.startsWith("https://", true) || !(raw.lowercase().endsWith(".mp3") || raw.contains(".mp3?"))) {
            status.text = "Enter a direct HTTPS .mp3 file URL that you are authorised to download."
            return
        }
        status.text = "Downloading…"
        worker.execute {
            try {
                val conn = URL(raw).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                conn.connect()
                if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
                val temp = File(cacheDir, "incoming.mp3")
                conn.inputStream.use { input -> temp.outputStream().use { input.copyTo(it) } }
                applyTags(temp)
                saveToMusicFolder(temp)
                runOnUiThread { status.text = "Saved to Music/Downloaded." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Download failed: ${e.message ?: "check the URL"}" }
            }
        }
    }

    private fun applyTags(file: File) {
        try {
            val audio = AudioFileIO.read(file)
            val tag = audio.tagOrCreateAndSetDefault
            if (trackTitle.isNotBlank()) tag.setField(FieldKey.TITLE, trackTitle)
            if (artist.isNotBlank()) tag.setField(FieldKey.ARTIST, artist)
            if (album.isNotBlank()) tag.setField(FieldKey.ALBUM, album)
            if (artworkUrl.isNotBlank()) {
                val bytes = URL(artworkUrl).openStream().use { input ->
                    val out = ByteArrayOutputStream(); input.copyTo(out); out.toByteArray()
                }
                tag.setField(ArtworkFactory.getNew().apply {
                    binaryData = bytes
                    mimeType = "image/jpeg"
                    description = "Album artwork"
                })
            }
            audio.commit()
        } catch (_: Exception) {
            // Keep the downloaded audio even if a source file has no writable ID3 tag.
        }
    }

    private fun saveToMusicFolder(file: File) {
        val safe = (if (artist.isBlank()) "" else "$artist - ") +
            (trackTitle.ifBlank { "Downloaded audio" }).replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "$safe.mp3")
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Downloaded")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("Could not create music file")
        contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            ?: throw Exception("Could not write music file")
        values.clear(); values.put(MediaStore.Audio.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
    }
}
