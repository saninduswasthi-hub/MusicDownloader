# Music Downloader (Android project)

## Included
- Android `ACTION_SEND` receiver for shared `text/plain` links.
- Dark Android UI.
- YouTube / YouTube Music link identification through YouTube oEmbed (title, channel/author, thumbnail URL).
- Download of an authorised direct HTTPS `.mp3` URL.
- Attempts to write ID3 title/artist/album and embedded artwork.
- Saves to `Music/Downloaded` using MediaStore (Android 10+).
- Minimum Android version: Android 6.0 (API 23); target API 35.

## Important limits
This app intentionally does **not** extract or download audio from YouTube Music. A shared YouTube Music URL is used only to identify the track. For an actual download, paste a direct MP3 URL from a source that permits downloading, or audio you own/control.

The selected 192 kbps setting is not yet enforced: this starter project preserves the bitrate of the supplied MP3. Re-encoding arbitrary audio to exactly 192 kbps requires adding and validating an MP3 encoder/transcoder. Do not treat a 192 kbps label as proof of source quality.

Artwork/metadata embedding is best-effort. Some MP3s may not support writing, and YouTube oEmbed may not return metadata for every URL.

## Build APK
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open this folder as an existing Gradle project.
3. Allow Gradle to sync and download dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

A prebuilt APK is not included because this build environment has Java but no Android SDK / Android Gradle build installation. The source project is provided so it can be built in Android Studio.
